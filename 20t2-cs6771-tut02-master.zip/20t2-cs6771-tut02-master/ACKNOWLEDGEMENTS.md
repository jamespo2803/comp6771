# Acknowledgements

Please see: https://gitlab.cse.unsw.edu.au/COMP6771/20T2-cs6771-lectures/-/blog/master/ACKNOWLEDGEMENTS.md