#include <catch2/catch.hpp>

auto sort_descending(std::vector<int>&) -> void;

TEST_CASE("sort_descending sorts in descending order") {}
