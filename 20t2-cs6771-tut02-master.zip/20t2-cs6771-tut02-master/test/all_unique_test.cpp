#include <catch2/catch.hpp>

auto all_unique(std::string const& word) -> bool;
auto all_unique_in_place(std::string const& word) -> bool;

TEST_CASE("all_unique with data structures") {}

TEST_CASE("all_unique with no extra data structures") {}
