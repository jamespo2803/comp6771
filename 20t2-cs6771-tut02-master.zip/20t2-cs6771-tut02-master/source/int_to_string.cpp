#include <string>
#include <vector>

auto int_to_string(std::vector<int> const&) -> std::string;
