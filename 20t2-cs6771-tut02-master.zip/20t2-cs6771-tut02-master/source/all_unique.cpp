#include <string>

// use this one for additional data structures
auto all_unique(std::string const& word) -> bool;

// use this one for no additional data structures
auto all_unique_in_place(std::string const& word) -> bool;
