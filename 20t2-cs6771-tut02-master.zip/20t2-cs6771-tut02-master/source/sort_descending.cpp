#include <vector>

auto sort_descending(std::vector<int>& numbers) -> void;
