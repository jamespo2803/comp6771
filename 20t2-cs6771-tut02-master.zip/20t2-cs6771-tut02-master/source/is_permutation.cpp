#include <string>

auto is_permutation(std::string const& x, std::string const& y) -> bool;
