# Setting up the environment on VLAB

Please see [week 1's setup instructions](https://gitlab.cse.unsw.edu.au/COMP6771/20T2-cs6771-tut01/-/blob/master/SETUP.md)